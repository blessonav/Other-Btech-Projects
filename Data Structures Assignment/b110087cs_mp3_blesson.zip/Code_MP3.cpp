#include<iostream>
#include <string.h>
#include<vector>
using namespace std;

class FoxAndMp3 
{

public:
	vector<string> playList(int n);
private:
	string num_to_str(int num);		
};

vector<string> FoxAndMp3::playList(int n) 
{
	FoxAndMp3 f2;
	string str;
	vector<string> v;
	int a[50];
	int i,m,p,q,r,s,t;
	 if(n>50)
		  n=50;
	
	m=n/10;
 	p=n%10;
	q=1;
	r=0;
	s=m;
	t=1;
	
	for(i=0;i<n;i++)
	{
 		if(i>11*m-10+p)   //IF1
   		{
   		   a[i]=s+1;
   		   s++;
   		}
  	        else              //ELSE PART OF IF1
  		{
  		   if(i%11==0)    //IF2
  		     {
  		       if(i%10 < m)  //IF3
  			 {
        		   a[i]=t;
        		   t++; 
      			 }
      		     }
     		    else            //ELSE PART OF IF2
      			{
        		   if(q==m)  //IF3
        		     {
         		       if(r<=p)   //IF4
          			 { 
             			   a[i] = q*10 + r;
             			   r++;
        			 }
        		     }

          		    if(q<m)     //IF5
        		     { 
          		       a[i]=q*10 + r;
           		       r++;
           		       if(r==10)     //IF6
          			  {
          			    r=0;
          			    q++;
           		          }
        		     }
        
     			 }
  		}
 	}
           
for(i=0;i<n;i++)
	{
	     str = f2.num_to_str(a[i]);
	     v.push_back(str);
	}
return v;


}


string FoxAndMp3::num_to_str(int num){
    string str = "";
    char ch;
    int n = 0;
    while(true){
        n = num % 10;
        switch(n){
            case 0: ch = '0'; 
		    break;
            case 1: ch = '1'; 
	            break;
            case 2: ch = '2';
		    break;
            case 3: ch = '3';
		    break;
            case 4: ch = '4';
		    break;
            case 5: ch = '5';
		    break;
            case 6: ch = '6';
		    break;
            case 7: ch = '7';
		    break;
            case 8: ch = '8';
		    break;
            case 9: ch = '9';
		    break;
            default : cout<<"Trouble converting number to string.";
        }
        num -= n;
        str = ch + str;
        if(num == 0){
            break;
        }
        num = num/10;
    }
    str=str + '.' + 'm' + 'p' + '3';
    return str;
}



int main()
{
vector<string> b;
double n;
int i,z;
z=1;
while(z==1)
{
	cout<<"enter the number of songs\n";
	cin>>n;
	if(n>1000000000|| n<1)
	{
         	cout<<"\nValue Entered is invalid.Please enter a number b/w 1 and 1000000000\n";
	        
	}
	else
	{	
		z=0;
	 	if(n>50)
 		   cout<<"\nFirst 50 songs are\n";
		else
		   cout<<"\n~~~SONGS LIST~~~\n";
     		   FoxAndMp3 f;
		   b=f.playList(n);
 		   cout<<"\n{";
		   for(i=0;i<b.size();i++)
		      {
	  	        cout<<b[i]<<"\n";
 	   	      }
		   cout<<"}\n\n";
	}
}
return 0;
}  
